package com.hcl.myhotel.constants;

/**
 * @author Sridhar reddy Constant class
 */

public class HotelConstants {
	public static final String ENTRY = "ENTRY";
	public static final String EXIT = "EXIT";
}
