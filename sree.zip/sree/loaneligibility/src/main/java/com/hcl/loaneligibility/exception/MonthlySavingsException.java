package com.hcl.loaneligibility.exception;

public class MonthlySavingsException extends Exception {

	public MonthlySavingsException(String message) {
		super(message);
	}

}
