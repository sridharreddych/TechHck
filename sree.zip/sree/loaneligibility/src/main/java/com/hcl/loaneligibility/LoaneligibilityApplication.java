package com.hcl.loaneligibility;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoaneligibilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoaneligibilityApplication.class, args);
	}
}
