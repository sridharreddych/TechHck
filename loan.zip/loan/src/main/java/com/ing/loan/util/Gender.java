package com.ing.loan.util;

public enum Gender {
	
	M,F;
	
}
