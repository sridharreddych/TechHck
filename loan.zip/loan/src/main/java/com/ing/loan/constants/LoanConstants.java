package com.ing.loan.constants;

public class LoanConstants {
	public static final String ENTRY = "ENTRY";
	public static final String EXIT = "EXIT";
}
