package com.ing.loan.exception;

public class LoanOfferException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoanOfferException(String message)
	{
		super(message);
	}
}
