package com.ing.loan.exception;

public class CustomerNotFoundExcetion extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerNotFoundExcetion(String message) {
		
	    super(message);	
	}
}
