package com.hcl.myhotel.exception;

public class HotelDetailsNotFoundException  extends Exception{

	/**
	 * @author Sridhar reddy
	 */
	private static final long serialVersionUID = 1L;

	public HotelDetailsNotFoundException(String message)
	{
		super(message);
	}

}
